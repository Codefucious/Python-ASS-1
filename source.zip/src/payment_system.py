import random
import pandas as pd
import os
from datetime import datetime

# Define exception handling class for salary validation
class SalaryValidationError(Exception):
    """Exception raised when salary is outside acceptable range"""
    pass

# Function to generate random worker data
def generate_workers(num_workers=400):
    """
    Generate a list of worker dictionaries with random data
    
    Args:
        num_workers: Number of workers to generate (default: 400)
    
    Returns:
        List of dictionaries containing worker information
    """
    try:
        first_names_male = ["James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph", "Thomas", "Charles"]
        first_names_female = ["Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Barbara", "Susan", "Jessica", "Sarah", "Karen"]
        last_names = ["Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson", "Moore", "Taylor",
                    "Anderson", "Thomas", "Jackson", "White", "Harris", "Martin", "Thompson", "Garcia", "Martinez", "Robinson"]
        
        job_titles = ["Carpenter", "Electrician", "Plumber", "Mason", "Foreman", "Supervisor", "Equipment Operator", 
                    "Painter", "Welder", "Inspector", "Laborer", "Engineer", "Project Manager", "Safety Officer", "Estimator"]
        
        workers = []
        
        for i in range(1, num_workers + 1):
            worker_id = f"HCC{i:04d}"
            gender = random.choice(["M", "F"])
            
            if gender == "M":
                first_name = random.choice(first_names_male)
            else:
                first_name = random.choice(first_names_female)
                
            last_name = random.choice(last_names)
            job_title = random.choice(job_titles)
            
            # Generate random salary based on job role with some variability
            base_salary = {
                "Carpenter": 4000, "Electrician": 5000, "Plumber": 4800, "Mason": 4200, "Foreman": 8000,
                "Supervisor": 12000, "Equipment Operator": 3500, "Painter": 3000, "Welder": 4500, 
                "Inspector": 9000, "Laborer": 2500, "Engineer": 18000, "Project Manager": 25000, 
                "Safety Officer": 9500, "Estimator": 11000
            }
            
            # Add randomness to the base salary (±20%)
            base = base_salary.get(job_title, 3000)
            salary = round(base * random.uniform(0.8, 1.2), 2)
            
            # Validate salary range
            if salary < 0:
                raise SalaryValidationError(f"Invalid negative salary generated for worker {worker_id}")
            
            hours_worked = round(random.uniform(30, 50), 1)
            
            workers.append({
                "worker_id": worker_id,
                "first_name": first_name,
                "last_name": last_name,
                "gender": gender,
                "job_title": job_title,
                "salary": salary,
                "hours_worked": hours_worked
            })
            
        return workers
    except Exception as e:
        print(f"Error generating worker data: {str(e)}")
        return []

# Function to determine employee level based on conditions
def determine_employee_level(worker):
    """
    Determine employee level based on salary and gender
    
    Args:
        worker: Dictionary containing worker information
        
    Returns:
        String representing employee level
    """
    try:
        salary = worker["salary"]
        gender = worker["gender"]
        
        # Apply conditional logic as specified
        if 10000 < salary < 20000:
            return "A1"
        elif 7500 < salary < 30000 and gender == "F":
            return "A5-F"
        else:
            # Default levels based on salary ranges
            if salary <= 5000:
                return "B2"
            elif 5000 < salary <= 10000:
                return "B1"
            elif 20000 <= salary < 30000:
                return "A2"
            else:
                return "A+"
    except KeyError as e:
        print(f"Missing key in worker data: {str(e)}")
        return "Unknown"
    except Exception as e:
        print(f"Error determining employee level: {str(e)}")
        return "Unknown"

# Function to generate payment slip
def generate_payment_slip(worker, level):
    """
    Generate a formatted payment slip for a worker
    
    Args:
        worker: Dictionary containing worker information
        level: String representing employee level
        
    Returns:
        String containing formatted payment slip
    """
    try:
        current_date = datetime.now().strftime("%Y-%m-%d")
        
        slip = f"""
---------------------------------------------------------
              HIGHRIDGE CONSTRUCTION COMPANY
                    WEEKLY PAYMENT SLIP
---------------------------------------------------------
Date: {current_date}
Worker ID: {worker['worker_id']}
Name: {worker['first_name']} {worker['last_name']}
Job Title: {worker['job_title']}
Employee Level: {level}
Hours Worked: {worker['hours_worked']} hours
Salary: ${worker['salary']:.2f}
---------------------------------------------------------
        """
        return slip
    except Exception as e:
        print(f"Error generating payment slip: {str(e)}")
        return f"Error generating payment slip for {worker.get('worker_id', 'unknown worker')}"

# Main function to process worker payments
def process_payments(output_dir="payment_slips"):
    """
    Process payments for all workers and generate payment slips
    
    Args:
        output_dir: Directory to save payment slips (default: payment_slips)
    """
    try:
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate worker data
        print(f"Generating data for 400 workers...")
        workers = generate_workers(400)
        
        if not workers:
            raise Exception("Failed to generate worker data")
        
        # Convert to DataFrame for data analysis
        df = pd.DataFrame(workers)
        
        # Initialize counters for levels
        level_counts = {"A1": 0, "A5-F": 0, "A+": 0, "A2": 0, "B1": 0, "B2": 0, "Unknown": 0}
        
        # Process each worker and generate payment slip
        print(f"Processing payment slips for {len(workers)} workers...")
        
        # Add employee level to each worker dictionary and count levels
        for i, worker in enumerate(workers):
            try:
                # Determine employee level
                level = determine_employee_level(worker)
                worker["employee_level"] = level
                level_counts[level] += 1
                
                # Generate payment slip
                slip = generate_payment_slip(worker, level)
                
                # Save slip to file
                filename = f"{output_dir}/{worker['worker_id']}_payment_slip.txt"
                with open(filename, "w") as f:
                    f.write(slip)
                
                # Progress indicator (every 40 workers)
                if (i + 1) % 40 == 0:
                    print(f"Progress: {i + 1}/{len(workers)} workers processed")
                    
            except Exception as e:
                print(f"Error processing worker {worker.get('worker_id', i)}: {str(e)}")
        
        # Update DataFrame with employee levels
        df["employee_level"] = [worker["employee_level"] for worker in workers]
        
        # Generate summary report
        print("\nPayment processing complete!")
        print("\nSummary Report:")
        print(f"Total workers processed: {len(workers)}")
        print("Employee Level Distribution:")
        for level, count in level_counts.items():
            print(f"  {level}: {count} workers")
        
        # Display worker list with name, salary, and employee level
        print("\nList of Workers (Name, Salary, Employee Level):")
        print("-" * 60)
        print(f"{'Name':<30} {'Salary':<12} {'Employee Level':<15}")
        print("-" * 60)
        
        # Sort by salary for better readability
        sorted_workers = sorted(workers, key=lambda x: x["salary"], reverse=True)
        
        # Display first 20 workers
        for i, worker in enumerate(sorted_workers[:20]):
            full_name = f"{worker['first_name']} {worker['last_name']}"
            print(f"{full_name:<30} ${worker['salary']:<10.2f} {worker['employee_level']:<15}")
        
        # Indicate there are more workers if applicable
        if len(workers) > 20:
            print(f"... and {len(workers) - 20} more workers (see CSV file for complete list)")
        
        # Save worker data to CSV
        df.to_csv(f"{output_dir}/worker_data.csv", index=False)
        print(f"\nWorker data saved to {output_dir}/worker_data.csv")
        print(f"Payment slips saved to {output_dir}/ directory")
        
    except Exception as e:
        print(f"Error in payment processing: {str(e)}")

# Execute the main function if script is run directly
if __name__ == "__main__":
    try:
        process_payments()
    except Exception as e:
        print(f"Fatal error: {str(e)}")