# Worker Payment System - R Implementation

# Load required libraries
library(dplyr)
library(lubridate)

# Define error handling function
handle_error <- function(error_message) {
  print(paste("ERROR:", error_message))
}

# Function to generate random worker data
generate_workers <- function(num_workers = 400) {
  tryCatch({
    first_names_male <- c("James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph", "Thomas", "Charles")
    first_names_female <- c("Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Barbara", "Susan", "Jessica", "Sarah", "Karen")
    last_names <- c("Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson", "Moore", "Taylor",
                   "Anderson", "Thomas", "Jackson", "White", "Harris", "Martin", "Thompson", "Garcia", "Martinez", "Robinson")
    
    job_titles <- c("Carpenter", "Electrician", "Plumber", "Mason", "Foreman", "Supervisor", "Equipment Operator", 
                   "Painter", "Welder", "Inspector", "Laborer", "Engineer", "Project Manager", "Safety Officer", "Estimator")
    
    # Create base salary lookup
    base_salary <- list(
      "Carpenter" = 4000, "Electrician" = 5000, "Plumber" = 4800, "Mason" = 4200, "Foreman" = 8000,
      "Supervisor" = 12000, "Equipment Operator" = 3500, "Painter" = 3000, "Welder" = 4500, 
      "Inspector" = 9000, "Laborer" = 2500, "Engineer" = 18000, "Project Manager" = 25000, 
      "Safety Officer" = 9500, "Estimator" = 11000
    )
    
    # Initialize empty data frame
    workers <- data.frame(
      worker_id = character(num_workers),
      first_name = character(num_workers),
      last_name = character(num_workers),
      gender = character(num_workers),
      job_title = character(num_workers),
      salary = numeric(num_workers),
      hours_worked = numeric(num_workers),
      stringsAsFactors = FALSE
    )
    
    # Generate worker data
    for (i in 1:num_workers) {
      worker_id <- sprintf("HCC%04d", i)
      gender <- sample(c("M", "F"), 1)
      
      if (gender == "M") {
        first_name <- sample(first_names_male, 1)
      } else {
        first_name <- sample(first_names_female, 1)
      }
      
      last_name <- sample(last_names, 1)
      job_title <- sample(job_titles, 1)
      
      # Get base salary for the job title
      base <- base_salary[[job_title]]
      if (is.null(base)) base <- 3000
      
      # Add randomness to salary (±20%)
      salary <- round(base * runif(1, 0.8, 1.2), 2)
      
      # Validate salary
      if (salary < 0) {
        handle_error(paste("Invalid negative salary generated for worker", worker_id))
        salary <- 0
      }
      
      hours_worked <- round(runif(1, 30, 50), 1)
      
      # Add worker to data frame
      workers[i, ] <- list(
        worker_id = worker_id,
        first_name = first_name,
        last_name = last_name,
        gender = gender,
        job_title = job_title,
        salary = salary,
        hours_worked = hours_worked
      )
    }
    
    return(workers)
  }, error = function(e) {
    handle_error(paste("Error generating worker data:", e$message))
    return(data.frame())
  })
}

# Function to determine employee level based on conditions
determine_employee_level <- function(worker) {
  tryCatch({
    salary <- worker$salary
    gender <- worker$gender
    
    # Apply conditional logic as specified
    if (salary > 10000 && salary < 20000) {
      return("A1")
    } else if (salary > 7500 && salary < 30000 && gender == "F") {
      return("A5-F")
    } else {
      # Default levels based on salary ranges
      if (salary <= 5000) {
        return("B2")
      } else if (salary > 5000 && salary <= 10000) {
        return("B1")
      } else if (salary >= 20000 && salary < 30000) {
        return("A2")
      } else {
        return("A+")
      }
    }
  }, error = function(e) {
    handle_error(paste("Error determining employee level:", e$message))
    return("Unknown")
  })
}

# Function to generate payment slip
generate_payment_slip <- function(worker, level) {
  tryCatch({
    current_date <- format(Sys.Date(), "%Y-%m-%d")
    
    slip <- paste0(
      "\n---------------------------------------------------------\n",
      "              HIGHRIDGE CONSTRUCTION COMPANY\n",
      "                    WEEKLY PAYMENT SLIP\n",
      "---------------------------------------------------------\n",
      "Date: ", current_date, "\n",
      "Worker ID: ", worker$worker_id, "\n",
      "Name: ", worker$first_name, " ", worker$last_name, "\n",
      "Job Title: ", worker$job_title, "\n",
      "Employee Level: ", level, "\n",
      "Hours Worked: ", worker$hours_worked, " hours\n",
      "Salary: $", sprintf("%.2f", worker$salary), "\n",
      "---------------------------------------------------------\n"
    )
    
    return(slip)
  }, error = function(e) {
    handle_error(paste("Error generating payment slip:", e$message))
    return(paste("Error generating payment slip for", worker$worker_id))
  })
}

# Main function to process worker payments
process_payments <- function(output_dir = "payment_slips_r") {
  tryCatch({
    # Create output directory if it doesn't exist
    dir.create(output_dir, showWarnings = FALSE)
    
    # Generate worker data
    cat("Generating data for 400 workers...\n")
    workers <- generate_workers(400)
    
    if (nrow(workers) == 0) {
      stop("Failed to generate worker data")
    }
    
    # Initialize counters for levels
    level_counts <- list("A1" = 0, "A5-F" = 0, "A+" = 0, "A2" = 0, "B1" = 0, "B2" = 0, "Unknown" = 0)
    
    # Process each worker and generate payment slip
    cat(paste0("Processing payment slips for ", nrow(workers), " workers...\n"))
    
    # Add employee level column to workers data frame
    workers$employee_level <- character(nrow(workers))
    
    for (i in 1:nrow(workers)) {
      tryCatch({
        worker <- workers[i, ]
        
        # Determine employee level
        level <- determine_employee_level(worker)
        workers$employee_level[i] <- level
        level_counts[[level]] <- level_counts[[level]] + 1
        
        # Generate payment slip
        slip <- generate_payment_slip(worker, level)
        
        # Save slip to file
        filename <- file.path(output_dir, paste0(worker$worker_id, "_payment_slip.txt"))
        writeLines(slip, filename)
        
        # Progress indicator (every 40 workers)
        if (i %% 40 == 0) {
          cat(paste0("Progress: ", i, "/", nrow(workers), " workers processed\n"))
        }
      }, error = function(e) {
        handle_error(paste("Error processing worker", workers$worker_id[i], ":", e$message))
      })
    }
    
    # Generate summary report
    cat("\nPayment processing complete!\n")
    cat("\nSummary Report:\n")
    cat(paste0("Total workers processed: ", nrow(workers), "\n"))
    cat("Employee Level Distribution:\n")
    for (level in names(level_counts)) {
      cat(paste0("  ", level, ": ", level_counts[[level]], " workers\n"))
    }
    
    # Display worker list with name, salary, and employee level
    cat("\nList of Workers (Name, Salary, Employee Level):\n")
    cat(paste0(rep("-", 60), collapse = ""), "\n")
    cat(sprintf("%-30s %-12s %-15s\n", "Name", "Salary", "Employee Level"))
    cat(paste0(rep("-", 60), collapse = ""), "\n")
    
    # Sort by salary for better readability and create a display data frame
    sorted_workers <- workers[order(workers$salary, decreasing = TRUE), ]
    
    # Display first 20 workers
    for (i in 1:min(20, nrow(sorted_workers))) {
      worker <- sorted_workers[i, ]
      full_name <- paste(worker$first_name, worker$last_name)
      cat(sprintf("%-30s $%-10.2f %-15s\n", full_name, worker$salary, worker$employee_level))
    }
    
    # Indicate there are more workers if applicable
    if (nrow(workers) > 20) {
      cat(paste0("... and ", nrow(workers) - 20, " more workers (see CSV file for complete list)\n"))
    }
    
    # Save worker data to CSV
    write.csv(workers, file.path(output_dir, "worker_data.csv"), row.names = FALSE)
    cat(paste0("\nWorker data saved to ", file.path(output_dir, "worker_data.csv"), "\n"))
    cat(paste0("Payment slips saved to ", output_dir, "/ directory\n"))
    
  }, error = function(e) {
    handle_error(paste("Error in payment processing:", e$message))
  })
}

# Execute the main function
tryCatch({
  process_payments()
}, error = function(e) {
  handle_error(paste("Fatal error:", e$message))
})